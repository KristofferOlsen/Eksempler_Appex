﻿Module LoginVariables
    Public Brukernavn As String
    Public Passord As String
    Public PassordKeyWord As String
End Module
